#include <stdio.h>
int main() {
    int arr[3][3][3] = {
        {
            {1, 4, 3},
            {4, 3, 6},
            {6, 8, 9}
       },
        {
            {1, 11, 12},
            {1, 4, 43},
            {6, 17, 18}
        },
        {
            {1, 0, 61},
            {3, 223, 64},
            {25, 246, 257}
        }
    };
	   int total_sum = 0;
    int max_val = arr[0][0][0];
    int min_val = arr[0][0][0];
    int total_elements = 3 * 3 * 3;
    printf("=== 3x3x3 3D ARRAY ANALYSIS ===\n");
    for (int i = 0; i < 3; i++) {
        int layer_sum = 0;
        printf("\n--- Layer %d ---\n", i + 1);
        for (int j = 0; j < 3; j++) {
            for (int k = 0; k < 3; k++) {
                int val = arr[i][j][k];
                layer_sum += val;
                total_sum += val;
                if (val > max_val) max_val = val;
                if (val < min_val) min_val = val;

                printf("%4d ", val);
            }
            printf("\n");
        }
        printf("Layer %d Total: %d\n", i + 1, layer_sum);
    }

    double overall_avg = (double)total_sum / total_elements;
    printf("\n=== OVERALL DATA INSIGHTS ===\n");
    printf("Total Sum of All Elements : %d\n", total_sum);
    printf("Overall Average      : %.2f\n", overall_avg);
    printf("Maximum Value           : %d\n", max_val);
    printf("Minimum Value        : %d\n", min_val);
    return 0;
}
