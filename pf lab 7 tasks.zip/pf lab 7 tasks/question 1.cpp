#include <stdio.h>
int main() {
    int mat[3][3];
    int trans[3][3];
    int cof[3][3];
    int adj[3][3];
    int inv[3][3];
    printf("=== 3x3 Matrix Analysis Program ===\n");
    printf("Enter the elements of the 3x3 matrix row by row:\n");
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            printf("Element [%d][%d]: ", i + 1, j + 1);
            scanf("%d", &mat[i][j]);
        }
    }
    printf("\n--- Stage 1: Original Matrix ---\n");
    for (int i = 0; i < 3; i++) {
        printf("  [ ");
        for (int j = 0; j < 3; j++) {
            printf("%8d ", mat[i][j]);
        }
        printf("]\n");
    }
    printf("\n");

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            trans[j][i] = mat[i][j];
        }
    }
    printf("--- Stage 2: Transpose Matrix ---\n");
    for (int i = 0; i < 3; i++) {
        printf("  [ ");
        for (int j = 0; j < 3; j++) {
            printf("%8d ", trans[i][j]);
        }
        printf("]\n");
    }
    printf("\n");

    int det = 0;
    for (int f = 0; f < 3; f++) {
        int sub[2][2];
        int r = 0, c = 0;
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                if (row != 0 && col != f) {
                    sub[r][c++] = mat[row][col];
                    if (c == 2) {
                        c = 0;
                        r++;
                    }
                }
            }
        }
        int det2x2 = (sub[0][0] * sub[1][1] - sub[0][1] * sub[1][0]);
        int sign = (f % 2 == 0) ? 1 : -1;
        det += sign * mat[0][f] * det2x2;
    }
    printf("--- Stage 3: Determinant ---\n");
    printf("  Determinant = %d\n\n", det);

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            int sub[2][2];
            int r = 0, c = 0;
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    if (row != i && col != j) {
                        sub[r][c++] = mat[row][col];
                        if (c == 2) {
                            c = 0;
                            r++;
                        }
                    }
                }
            }
            int det2x2 = (sub[0][0] * sub[1][1] - sub[0][1] * sub[1][0]);
            int sign = ((i + j) % 2 == 0) ? 1 : -1;
            cof[i][j] = sign * det2x2;
        }
    }
    printf("--- Stage 4: Cofactor Matrix ---\n");
    for (int i = 0; i < 3; i++) {
        printf("  [ ");
        for (int j = 0; j < 3; j++) {
            printf("%8d ", cof[i][j]);
        }
        printf("]\n");
    }
    printf("\n");

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            adj[j][i] = cof[i][j];
        }
    }
    printf("--- Stage 5: Adjoint Matrix ---\n");
    for (int i = 0; i < 3; i++) {
        printf("  [ ");
        for (int j = 0; j < 3; j++) {
            printf("%8d ", adj[i][j]);
        }
        printf("]\n");
    }
    printf("\n");

    printf("--- Stage 6: Inverse Matrix ---\n");
    if (det == 0) {
        printf("  Matrix is singular (Determinant is 0). Inverse does not exist.\n");
    } else {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                inv[i][j] = adj[i][j] / det;
            }
        }
        for (int i = 0; i < 3; i++) {
            printf("  [ ");
            for (int j = 0; j < 3; j++) {
                printf("%8d ", inv[i][j]);
            }
            printf("]\n");
        }
    }

    return 0;
}
