#include <stdio.h>
int main() {
    int r, c;
    printf("Enter rows (up to 5): ");
    scanf("%d", &r);
    printf("Enter columns (up to 5): ");
    scanf("%d", &c);
    int mat[5][5];
    printf("Enter matrix elements:\n");
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            scanf("%d", &mat[i][j]);
        }
    }
    printf("\n--- MATRIX TYPES ANALYSIS ---\n");

    if (r == c)
    {
        printf("- Square Matrix\n");
    }
    else
    {
        printf("- Rectangular Matrix\n");
    }

    if (r == 1)
    {
        printf("- Row Matrix\n");
    }
    if (c == 1)
    {
        printf("- Column Matrix\n");
    }

    int is_zero = 1, is_diagonal = 1, is_scalar = 1, is_identity = 1;
    int is_upper = 1, is_lower = 1, is_symmetric = 1, is_skew = 1;
    int scalar_val = 0;
    if (r == c && r > 0)
    {
        scalar_val = mat[0][0];
    }

    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            if (mat[i][j] != 0)
            {
                is_zero = 0;
            }

            if (i != j) {
                if (mat[i][j] != 0)
                {
                    is_diagonal = 0;
                }
                if (mat[i][j] != 0)
                {
                    is_scalar = 0;
                }
                if (mat[i][j] != 0)
                {
                    is_identity = 0;
                }
            } else {
                if (mat[i][i] != scalar_val)
                {
                    is_scalar = 0;
                }
                if (mat[i][i] != 1)
                {
                    is_identity = 0;
                }
            }

            if (r == c) {
                if (i > j && mat[i][j] != 0)
                {
                    is_upper = 0;
                }
                if (i < j && mat[i][j] != 0)
                {
                    is_lower = 0;
                }
                if (mat[i][j] != mat[j][i])
                {
                    is_symmetric = 0;
                }
                if (mat[i][j] != -mat[j][i] || (i == j && mat[i][j] != 0))
                {
                    is_skew = 0;
                }
            } else {
                is_upper = 0;
                is_lower = 0;
                is_symmetric = 0;
                is_skew = 0;
            }
        }
    }

    if (is_zero)
    {
        printf("- Zero Matrix (Null Matrix)\n");
    }
    if (r == c) {
        if (is_diagonal)
        {
            printf("- Diagonal Matrix\n");
        }
        if (is_scalar)
        {
            printf("- Scalar Matrix\n");
        }
        if (is_identity)
        {
            printf("- Identity Matrix\n");
        }
        if (is_upper)
        {
            printf("- Upper Triangular Matrix\n");
        }
        if (is_lower)
        {
            printf("- Lower Triangular Matrix\n");
        }
        if (is_symmetric)
        {
            printf("- Symmetric Matrix\n");
        }
        if (is_skew)
        {
            printf("- Skew-Symmetric Matrix\n");
        }

        int prod[5][5] = {0};
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                for (int k = 0; k < c; k++) {
                    prod[i][j] += mat[i][k] * mat[k][j];
                }
            }
        }
        int is_idempotent = 1;
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                if (prod[i][j] != mat[i][j])
                {
                    is_idempotent = 0;
                    break;
                }
            }
        }
        if (is_idempotent)
        {
            printf("- Idempotent Matrix\n");
        }
    }

    return 0;
}
