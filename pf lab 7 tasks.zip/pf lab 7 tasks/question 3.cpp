#include <stdio.h>
int main() {
    int a[3][3], b[3][3], res[3][3] = {0};
    int r1, c1, r2, c2, i, j, k;
    printf("Enter rows & cols for Matrix 1 (max 3x3): ");
    scanf("%d %d", &r1, &c1);
    printf("Enter elements of Matrix 1:\n");
    for(i = 0; i < r1; i++)
        for(j = 0; j < c1; j++)
            scanf("%d", &a[i][j]);
    printf("Enter rows & cols for Matrix 2 (max 3x3): ");
    scanf("%d %d", &r2, &c2);
    printf("Enter elements of Matrix 2:\n");
    for(i = 0; i < r2; i++)
        for(j = 0; j < c2; j++)
            scanf("%d", &b[i][j]);
    if (c1 != r2 || r1 < 1 || r1 > 3 || c1 < 1 || c1 > 3 || r2 < 1 || r2 > 3 || c2 < 1 || c2 > 3) {
        printf("\nError: Multiplication not possible! Check size limits (1-3) and ensure Matrix 1 columns == Matrix 2 rows.\n");
        return 1;
    }
    for(i = 0; i < r1; i++) {
        for(j = 0; j < c2; j++) {
            for(k = 0; k < c1; k++) {
                res[i][j] += a[i][k] * b[k][j];
            }
        }
    }
    printf("\nMatrix 1:\n");
    for(i = 0; i < r1; i++) {
        for(j = 0; j < c1; j++) printf("%d\t", a[i][j]);
        printf("\n");
    }
    printf("\nMatrix 2:\n");
    for(i = 0; i < r2; i++) {
        for(j = 0; j < c2; j++) printf("%d\t", b[i][j]);
        printf("\n");
    }
    printf("\nResultant Matrix:\n");
    for(i = 0; i < r1; i++) {
        for(j = 0; j < c2; j++) printf("%d\t", res[i][j]);
        printf("\n");
    }
    
    return 0;
}
